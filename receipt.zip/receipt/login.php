<?php 
session_start();

$page_url = basename($_SERVER['PHP_SELF']);
if(isset($_SESSION['userid']))
{
	echo "<script>window.location.href='index.php';</script>";
}
else
{
	include "config.php";		
	$user_table = DBPRE."_users"; //table Define

	if(isset($_POST['btn_login']))
	{
		// Escape special characters, if any
		$name = $con -> real_escape_string($_POST['user_name']);
		$password = $con -> real_escape_string($_POST['password']);
        
		$select_query = "SELECT * FROM $user_table WHERE username='$name' AND paswd='$password'";
		$result = $con->query($select_query);
		$con->close();
		
		if($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc())
			{
				if($row['status'] == 'A')
				{
					$_SESSION['userid'] = $row['id'];
					$_SESSION['username']  = $row['full_name'];
					$_SESSION['useremail'] = $row['email'];
					echo "<script>window.location.href='index.php';</script>";
				}
				else
				{
					echo "<script>alert('Access Denied');</script>";
					echo "<script>window.location.href='".$page_url."';</script>";
				}	
			}
		} 
		else
			{
				echo "<script>alert('The user Name or password you have entered is incorrect.');</script>";
				echo "<script>window.location.href='".$page_url."';</script>";
		}	
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <style>
      .card_center{
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;
          width: 100%;
          height: 100vh;
      }
  </style>
  
</head>
<body class="card_center">
    
<div class="container">
  <div class="row">
    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 m-auto">
        <div class="card">
          <div class="card-header">User Login</div>
            <div class="card-body">
                <form method="post">
                  <div class="form-group has-feedback">
                    <input type="text" class="form-control sty1" name="user_name" id="user_name" placeholder="User Name">
                  </div>
                  <div class="form-group has-feedback">
                      <input type="password" class="form-control sty1" name="password" id="password" placeholder="Password">
                  </div>
                  <div>
                      <div class="col-xs-4 m-t-1">
                        <button type="submit" name="btn_login" id="btn_login" class="btn btn-primary btn-block btn-flat">Login Now</button>
                      </div>
                  </div>
            </div>
      </form>
    </div>
    </div>
    
    
          
  </div>
</div>
</body>
</html>


<?php
    }
?>