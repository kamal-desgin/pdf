<?php
    $con = new mysqli("localhost","future_user","dY1i-J;]gN16","futurenavigator");
    
    // Check connection
    if ($mysqli -> connect_errno) {
      echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
      exit();
    }
    //echo "Connected successfully";
    
    $con->set_charset("utf8");
    define("DBPRE","fn"); //DB prefix
    define("TITLE","Future Navigators"); //Title
?>
