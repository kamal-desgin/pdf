<?php 
session_start();

if(isset($_SESSION['userid']))
{
      include_once("config.php");
      $update = false;
      $select = false;
      $page_url = basename($_SERVER['PHP_SELF']);
      
      date_default_timezone_set('Asia/Kolkata');
      
      $page_title = " Receipt Details";
      $sub_page_title = "Receipt";
      $table_name  = DBPRE."_receipt"; 
      
        $message = '';
        $name = '';
        $error = '';
        //clean email check
        function clean_text($string)
        {
        	$string = trim($string);
        	$string = stripslashes($string);
        	$string = htmlspecialchars($string);
        	return $string;
        }
        if(empty($_POST["email"]))
        {
        	$error .= '<p><label class="text-danger">Please Enter your Email</label></p>';
        }
        else
        {
        	$email = clean_text($_POST["email"]);
        	if(!filter_var($email, FILTER_VALIDATE_EMAIL))
        	{
        		$error .= '<p><label class="text-danger">Invalid email format</label></p>';
        	}
        }
        
        //PDF Function
        function fetch_customer_data($con, $data)
        {
            $select_query = "SELECT * FROM fn_receipt WHERE id='$data' ";
            $result = $con->query($select_query);
            $htmlcontent = ''; 
            if ($result){
				$data = mysqli_fetch_array($result);
            }
            //Mail Configs
			$mail_website_url = "https://futurenavigatorsedu.com/";
			$mail_bg = "url(http://androidandiosdevelopment.com/demo/mailsend/mailbg.jpg) no-repeat"; //Image pah or color code
			$mail_phone = "+91 7397269369 / 7358350750 / 044 - 48526777";
			$mail_email = "futurenavigatorsedu@gmail.com";
			$mail_copyright = "FUTURE NAVIGATORS";
			$mail_copyright_url = $mail_website_url;
            $year =  date('Y');
                
        	//Mail			
        	$mail_h4 = "Future Navigators";
        	$mail_h1 = "RECEIPT";
        	$mail_main_msg = "<p style='text-align:center;font-size:16px;font-wight:500;padding-top:40px; word-spacing:8px;line-height: 30px;'>&nbsp; &nbsp; We have received with thanks from <u><b>$data[name]</b></u><br>
        	                  S/O <u><b>$data[fathername]</b></u> <br>
        					  Residing at <u><b>$data[address]</b></u><br>
        					  A Sum of Rupees <u><b>$data[ruppessword]</b></u><br>
        					  On account of <u><b>$data[purpose]</b></u> dated <u><b>$data[paydate]</b></u> <br>
        					  By Cash / Cheque / DD NO: <u><b>$data[cheque]<b></u>, Bank Name & Branch <u><b>$data[bankname]</b></u></p><br>
        					  
        					  <p style='border:2px solid #000; width:100px; padding:10px 20px; text-align:left; font-weight:bold; font-size: 16px;'>$data[cash] /-</p> <br>
        					  <p style='font-size:16px;font-wight:500;padding-top:25px;padding-bottom:25px; word-spacing:8px;line-height: 30px;'> <b>Remarks:</b> <u>$data[remarks]</u>_______</p>
        					  <p style='font-size:16px;font-wight:500; word-spacing:8px;'> For FUTURE NAVIGATORS <br><br><br>Authorized Signatory</p>";
        					  
        	$mail_footer = '<p style="font-size:14px;text-align:center; line-height:24px;"> Address: No: 228/10, 2nd Floor, GST Road, Near MIT Bridge, Chrompet, Chennai - 600 044 <br>
					                    E-mail: info@futurenavigatorsedu.com,    Web: www.futurenavigatorsedu.com<br>
					                    Call: +91 7397269369 / 7358350750 / 044- 48526777 </p>
						            <p style="font-size:14px;text-align:center;">Copyright &copy; '.date("Y").' <a href="'.$mail_copyright_url.'" style="text-decoration:none;font-weight:bold;">'.$mail_copyright.'</a></p>';				  
            
        	$htmlcontent = '<html>
                             <head>
                                <style>
                                    @page {
                                        margin: 0cm 0cm;
                                    }
                                </style>
                            </head>
                            <body style="width:100%; height:100vh;font-family:Arial,Helvetica,sans-serif;margin-top: 2cm;margin-left: 2cm;margin-right: 2cm;margin-bottom: 2cm;">
        						<header style="position: fixed;top: 0cm;left: 0cm;right: 0cm;height: 4cm;text-align: center;line-height: 1.5cm;border-bottom: 1px solid  #03a9f4;">
                                   <table style="width:100%; padding-top:25px; padding-bottom:25px;">
                                        <tr>
                                            <td style="width:80%;"><img src="https://futurenavigatorsedu.com/logo/mlogo-1.jpg" style="padding-top:40px;padding-left:60px;" width="350px"></td>
                                            <td style="width:20%;"> <img src="https://futurenavigatorsedu.com/logo/mlogo-2.jpg" width="125px"> </td>
                                        </tr>
                                    </table>
                                </header>
        						<footer style="position: fixed;bottom: 0cm;left: 0cm;right: 0cm;height: 4cm;border-top: 3px solid  #03a9f4;text-align: center;">'.$mail_footer.'</footer>
        						<main style="margin-top:100px !important;">
        						    <h1 style="font-family:Arial,Helvetica,sans-serif;font-size:18px;font-weight:bold;padding-top:35px;padding-bottom:20px;text-align:center;">'.$mail_h1.'</h1>
        						    <div style="padding:15px 10px;">'.$mail_main_msg .'</div>
        						</main>
        					
        					</body>
        				</html>';
                return $htmlcontent;
        }//function END 

     //Save Section   
    if(isset($_POST["save"]))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
		$fathername = $_POST['fathername'];
		$address = $_POST['address'];
		$rupess = $_POST['rupess'];
		$purpose = $_POST['purpose'];
		$date = $_POST['date'];
		$date = date("Y-m-d", strtotime($date));
		$cheque = $_POST['cheque'];
		$bank = $_POST['bank'];
		$cash = $_POST['cash'];
		$receiptdate = $_POST['receiptdate'];
		$receiptdate = date("Y-m-d", strtotime($receiptdate));
		$referencenumber = $_POST['referencenumber'];
		$gst = $_POST['gst'];
		$gtotal = $_POST['gtotal'];
		$remarks = $_POST['remarks'];
		
		$insert_sql=" INSERT INTO $table_name (`name`, `email`, `fathername`, `address`, `ruppessword`, `purpose`, `paydate`, `receiptdate`, `cheque`, `bankname`, `cash`,`referencenumber`, `gst`, `gtotal`, `remarks`) VALUES ('$name', '$email', '$fathername', '$address', '$rupess', '$purpose', '$date', '$receiptdate', '$cheque', '$bank', '$cash', '$referencenumber', '$gst', '$gtotal', '$remarks') ";
		$result = $con->query($insert_sql) or die(mysqli_error($con));
		$lastInsertId = $con->insert_id;
		
		
	
		//PDF SECTION
		include('pdf.php');
        $file_name = md5(rand()) . '.pdf';
    	$html_code  = '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>';
    	$html_code .= fetch_customer_data($con,$lastInsertId);
    	$pdf = new Pdf();
    	$pdf->load_html($html_code);
    	$pdf->render();
    	$file = $pdf->output();
    	file_put_contents($file_name, $file);
    	
    	
    	$mailbody = '<table style="font-family: Arial,Helvetica,sans-serif;color: #222; font-size: 16px; width: 600px;margin: 12px auto;box-shadow: 2px 5px 10px rgba(0,0,0,0.2); border-radius: 4px; padding: 20px; border: 1px solid #efefef; background-color:#fbfbfb;" cellpadding="12">
								<tbody style="padding:20px 0;">
								<tr style="padding:20px 0;">
									<td colspan="2" style="width:40%;"><img src="https://futurenavigatorsedu.com/images/study-abroad-consultants-in-chennai.png" width="100%"></td>
									<td colspan="3" style="text-align:right;line-height:1.7; text-decoration:none;">Contact: +044-4852 6777 <br>Email: info@futurenavigatorsedu.com</td>
								</tr>
								<tr>
									<td colspan="5" style="text-align:center;color:#131313;">
										<h4>Online Receipt</h4>
									</td>
								</tr>
								<tr>
									<td colspan="5">
										<p>We have received with thanks from <b>'.$name.'</b> Attached receipt for your reference. </p>
							        	<hr>
										<p style="font-size:12px;text-align:center;">This email was sent from a notification-only address that cannot accept incoming email. Please do not reply to this message.<br>
										Copyright &copy; 2020 <a href="https://futurenavigatorsedu.com/" style="text-decoration:none;font-weight:bold;">www.futurenavigatorsedu.com</a></p>
									</td>
								</tr>
								</tbody>
							</table>';
    	
    
        //PHPMailer START
		require 'class/class.phpmailer.php';
		require 'class/class.smtp.php';
		$mail = new PHPMailer;
		$mail->IsSMTP(); 
        //$mail->SMTPDebug = 1;
        $mail->IsHTML(true);
		$mail->From = $email;					
		$mail->FromName = $name;	
		$mail->AddAddress('smkamal.sm@gmail.com', 'Name');
		$mail->AddCC($email, $name);
		$mail->WordWrap = 50;
		$mail->AddAttachment($file_name);
		$mail->Subject = 'Future Navigator Receipt';
		$mail->Body = $mailbody;
	
                							     
		if($mail->Send())					
		{
			$message = '<label class="text-success">Receipt Save Successfully.</label>';
			echo "<script>alert('Future Navigators Receipt Send Successfully.');</script>";
			echo "<script>window.location.href='".$page_url."';</script>";
		}
		else
		{
			$message = '<label class="text-danger">There is an Error</label>';
			echo "<script>window.location.href='".$page_url."';</script>";
		}
		unlink($file_name);
    }
    
    
    //Update Section
    if(isset($_POST["update"]))
    {
        $id = $_GET['eid'];	
        $name = $_POST['name'];
        $email = $_POST['email'];
		$fathername = $_POST['fathername'];
		$address = $_POST['address'];
		$rupess = $_POST['rupess'];
		$purpose = $_POST['purpose'];
		$date = $_POST['date'];
		$date = date("Y-m-d", strtotime($date));
		$cheque = $_POST['cheque'];
		$bank = $_POST['bank'];
		$cash = $_POST['cash'];
		$receiptdate = $_POST['receiptdate'];
		$receiptdate = date("Y-m-d", strtotime($receiptdate));
		$referencenumber = $_POST['referencenumber'];
		$gst = $_POST['gst'];
		$gtotal = $_POST['gtotal'];
		$remarks = $_POST['remarks'];
		
		$update_sql = " UPDATE $table_name SET name='$name', email='$email', fathername='$fathername', address='$address', ruppessword='$rupess', purpose='$purpose', paydate='$date', receiptdate='$receiptdate', cheque='$cheque', bankname='$bank', cash='$cash', referencenumber='$referencenumber', gst='$gst', gtotal='$gtotal', remarks='$remarks' WHERE id='$id' ";
		$result = $con->query($update_sql) or die(mysqli_error($con));
		$con->close();
		
		if((empty($error)) == (isset($result)))
		{
			echo "<script>alert('$msg_title Updated successfully!');</script>";
			echo "<script>window.location.href='".$page_url."';</script>";
		}
    }  
       
    if(isset($_GET['ac']))
    {   
        //Delete single records
    	if($_GET['ac']=="delete")
    	{
    		$id = $_GET['id'];
    		$delete_query="DELETE FROM $table_name WHERE id=$id ";
    		$result = $con->query($delete_query) or die(mysqli_error($con));
    		$con->close();		
    		echo "<script>alert('$msg_title deleted successfully!');</script>";
    		echo "<script>window.location.href='".$page_url."';</script>";
    	}
    }
?>


<!DOCTYPE html>
				<html>
					<head>
						<title>Create Receipt</title>
						<meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1">
                        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
                        <script>
                        	$(function() { $('.datepicker').datepicker("setDate", new Date()); });
                        </script>
                        <script src="https://use.fontawesome.com/90f8046a87.js"></script>
                        <!--datatable-->
                        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
                        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap.min.css">
                        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
                        <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap.min.js"></script>
                        <style>
                            .form-control { border-radius: 0px; };
                        </style>
                        
                    </head>
					<body>
						<header>
						    <nav class="navbar navbar-inverse">
                                  <div class="container-fluid">
                                    <div class="navbar-header">
                                      <a class="navbar-brand" href="https://futurenavigatorsedu.com/">Future Navigators</a>
                                    </div>
                                    <!--<ul class="nav navbar-nav">
                                      <li class="active"><a href="#">Home</a></li>
                                      <li><a href="#">Page 1</a></li>
                                      <li><a href="#">Page 2</a></li>
                                    </ul>-->
                                    <ul class="nav navbar-nav navbar-right">
                                      <li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Login</a></li>
                                      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
                                    </ul>
                                  </div>
                                </nav>
						</header>
						<br />
						<br />
						<div class="container">
						    <div class="row">
						            <?php
                                        if(isset($_GET['ac']))
                                        {					
                                			if($_GET['ac'] == "new")//Add New
                                            {
                                				//update section 				
                                				if(isset($_GET['eid']))
                                				{									
                                					$eid = $_GET['eid'];
                                					$update = true; //set update true					
                                					$demo_quotaion = "select * from $table_name where id='$eid'";
                                					$record = $con->query($demo_quotaion) or die(mysqli_error($con)); //total record count
                                					if ($record){
                                						$demo_data = mysqli_fetch_array($record);
                                					}
                                					$form_name = 'Receipt Edit';
                                				}
                                				elseif(isset($_GET['sid']))
				                                {
				                                    $sid = $_GET['sid'];
					                                $select = true; //set select true	
				                                    $demo_quotaion = "select * from $table_name where id='$sid'";
                                					$record = $con->query($demo_quotaion) or die(mysqli_error($con)); //total record count
                                					if ($record){
                                						$demo_data = mysqli_fetch_array($record);
                                					}
                                					$form_name = 'View Receipt';
                                					echo "<style>
                                					          .input_read { pointer-events: none; }
                                					       </style>
                                					        <script>
                                							$(document).ready(function(){								
                                								$('.form-control').addClass('input_read');
                                							});
                                						</script>";
				                                }
                                				else {
                                    					$form_name = 'Add New Receipt';	
                                    					/*echo "<script>
                                							$(document).ready(function(){								
                                								$('.form-control').removeAttr('id');
                                							});
                                						</script>"; */
                                    				}
                                    	      ?>
                                 
                                 
                                         <div class="col-md-offset-1 col-lg-10 col-md-12 col-sm-12 col-xs-12 well-sm well">   	      
                                    	    <h3 class="text-center" style="font-weight:bold;"><php echo $form_name; ?></h3>
                							
                					        <?php echo $message; ?>
                					        
                							<form method="POST">
                								<div class="form-group col-sm-4">
                									<label>Full Name</label>
                									<input type="text" name="name" id="name" class="form-control" placeholder="Full Name" required />
                								</div>
                								<div class="form-group col-sm-4">
                									<label>Email id</label>
                									<input type="text" name="email" id="email" class="form-control" placeholder="Email address" value="<?php echo $email; ?>"  required />
                								</div>
                								<div class="form-group col-sm-4">
                									<label>Father Name</label>
                									<input type="text" name="fathername" id="fathername" class="form-control" placeholder="Father Name" required />
                								</div>
                							    	<div class="form-group col-sm-12">
                									<label>Address</label>
                									<input type="text" name="address" id="address" class="form-control" placeholder="Rupess in Letters" required />
                								</div>
                								<div class="form-group col-sm-8">
                									<label>Rupess in Letters</label>
                									<input type="text" name="rupess" id="rupess" class="form-control" placeholder="Rupess in Letters"  required />
                								</div>
                								<div class="form-group col-sm-4">
                									<label>Purpose</label>
                									<input type="text" name="purpose" id="purpose" class="form-control" placeholder="Purpose" required />
                								</div>
                								<div class="form-group col-sm-2">
                									<label>Paydate</label>
                									<input type="text" name="date" id="date" class="datepicker form-control" placeholder="Date" value="<?php echo $demo_data["paydate"]; ?>" readonly />
                								</div>
                								<div class="form-group col-sm-2">
                									<label>Receipt Date</label>
                									<input type="text" name="receiptdate" id="receiptdate" class="datepicker form-control" placeholder="Date" readonly />
                								</div>
                								<div class="form-group col-sm-2">
                									<label>Cash/Cheque/DDNO</label>
                									<input type="text" name="cheque" id="cheque" class="form-control" placeholder="DD NO" />
                								</div>
                								<div class="form-group col-sm-4">
                									<label>Bank Name</label>
                									<input type="text" name="bank" id="bank" class="form-control" placeholder="Bank Name" />
                								</div>
                								<div class="form-group col-sm-2">
                									<label>Cash Numbers</label>
                									<input type="number" name="cash" id="cash" class="form-control" placeholder="Cash Numbers" required />
                								</div>
                								<div class="form-group col-sm-4">
                									<label>Reference Numbers</label>
                									<input type="text" name="referencenumber" id="referencenumber" class="form-control" placeholder="Reference number" />
                								</div>
                								<div class="form-group col-sm-2">
                									<label>GST</label>
                									<input type="number" name="gst" id="gst" class="form-control" placeholder="gst" />
                								</div>
                								<div class="form-group col-sm-2">
                									<label>Reference Total</label>
                									<input type="text" name="gtotal" id="gtotal" class="form-control text-danger" placeholder="" readonly/>
                								</div>
                								<div class="form-group col-sm-12">
                									<label>Remarks</label>
                									<textarea rows="2" name="remarks" id="remarks" class="form-control" placeholder="Remarks"><?php echo $demo_data['remarks']; ?></textarea>
                								</div>
                								
                								<div class="form-group col-sm-12 text-center">
                                        					<?php if($update == true) 
                                        					{
                                        					?>
                                        					<button class="btn btn-success" type="submit" name="update" id="clickMe" onclick="back()"> Update </button>
                                        					<?php 
                                        					} 
                                        					elseif ($select == true) 
                                        					{
                                        					?>
                                        					<button class="btn btn-success" type="button" name="view_data" id="view_data" onclick="back()" disabled>Only View </button>
                                        					<?php 
                                        					}  
                                        					elseif ($update == false || $select == false)
                                        					{ 
                                        					?>
                                        					<!--<input type="button" id="clickMe" value="Submit ALL" />-->
                                        					<button type="submit"  class="btn btn-success"  name="save" id="clickMe" onclick="clear()"> Save</button>
                                        					<?php 
                                        					} 
                                        					?>
                                        				<a href="<?php echo $page_url; ?>" class="btn btn-danger"> Cancel</a>
                                        			
                								</div>
                							</form>
                                    	</div> 
                                    	<?php			
                                            }
                                            if($_GET['ac'] == "print")//PDF VIEW
                                            {
                                                    $pdfid = $_GET['pid'];
                							        //PDF Print section
                                            		include('pdf.php');
                                                	$html_code2  = '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>';
                                                	$html_code2 .= fetch_customer_data($con,$pdfid);
                                                    $pdf = new Pdf();
                                                	$pdf->load_html($html_code2);
                                                	$pdf->setPaper('A4', 'portrait');
                                                	$pdf->render();
                                                	ob_end_clean();
                                                	$pdf->stream("receipt", array("Attachment"=>0));
                                                	exit;
                                           } 
                                        }
                                        if(!isset($_GET['ac']))//table View 
                                        {
                                         ?>  
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                           <div class="panel panel-default">
                                              <div class="panel-heading"> Receipt Details
                                                 <a href="?ac=new" class="btn btn-primary btn-sm pull-right"> <i class="fa fa-plus"></i> Add New</a>
                                              </div>
                                              <div class="panel-body">
                                                
                                                <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                                                    <thead>
                                                        <tr>
                                                            <th width="5%">S.No</th>
                                                            <th>Name</th>
                                                            <th>Email</th>
                                                            <th>Cash</th>
                                                            <th>Purpose of</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                           $sel_query = " SELECT * FROM $table_name ORDER BY id DESC";
                                                            $result = $con->query($sel_query);
                                                           
                                                            if($result->num_rows > 0)
                                                            {
                                                               
                                                               $i=0;
                                                                while($row= $result->fetch_assoc()){
                                                                  $i++;
                                                                    echo "<tr>
                                                                                <td>$i</td>
                                                                                <td>$row[name]</td>
                                                                                <td>$row[email]</td>
                                                                                <td>$row[cash]</td>
                                                                                <td>$row[purpose]</td>
                                                                                <td>
                                                                                    <ul class='list-inline'> 
                                                                                        <li><a class='btn btn-danger btn-sm' href='?ac=print&pid=$row[id]' target='_blank' title='PDF'><i class='fa fa-file-pdf-o'></i></a></li>
                                                                                        <li><a class='btn btn-success btn-sm' href='?ac=new&eid=$row[id]' title='Edit'><i class='fa fa-pencil'></i></a></li>
                                                                                        <li><a class='btn btn-primary btn-sm' href='?ac=new&sid=$row[id]' title='View'><i class='fa fa-eye'></i></a></li>
                                                                                        <li><a class='btn btn-danger btn-sm' href='javascript:isDel(".$row['id'].")' title='Delete'><i class='fa fa-trash-o '></i></a> </li>
                                                                                    </ul>
                                                                                </td>
                                                                            </tr>";
                                                                    
                                                                      echo "<script>
                                    											function isDel(id)
                                    											{
                                    												if(confirm('Are you sure you want to delete this Record?'))
                                    												{
                                    													document.location.href=\"?ac=delete&id=\"+id;
                                    													document.location.target='parent';
                                    												}
                                    											}
                                											</script>";
                                                                } 
                                                                
                                                            } else {
                                                                echo "No Data Found";
                                                            }
                                                        ?>
                                                       
                                                    </tbody>
                                                </table>
                                                
                                              </div>
                                            </div>
                                        </div>
                                    <?php       
                                        } 
                                	?>	    
                                
							</div>
						</div>
						<br /><br />
					<script>
					    $(document).ready(function(){
					        //data table
                            $('#datatable').DataTable();
                            
                           $(document).on('blur','#gst, #cash',function(){
            					//var gst = $(this).val();
            					var gst = $('#gst').val();
            					var  cash = $('#cash').val();
            					gstprice = parseFloat(cash) + parseFloat(gst * (cash / 100));
            					var totalRound = parseFloat(gstprice);
            					var payamount = Math.round(totalRound);
            					$('#gtotal').val(payamount + '/- Pay');
            				});
                            
                            //selected value
					        $('#name').val("<?php echo $demo_data["name"]; ?>");
					        $('#email').val("<?php echo $demo_data["email"]; ?>");
					        $('#fathername').val("<?php echo $demo_data["fathername"]; ?>");
					        $('#address').val("<?php echo $demo_data["address"]; ?>");
					        $('#rupess').val("<?php echo $demo_data["ruppessword"]; ?>");
					        $('#purpose').val("<?php echo $demo_data["purpose"]; ?>");
					        $('#date').val("<?php echo $demo_data["paydate"]; ?>");
					        $('#receiptdate').val("<?php echo $demo_data["receiptdate"]; ?>");
					        $('#cheque').val("<?php echo $demo_data["cheque"]; ?>");
					        $('#bank').val("<?php echo $demo_data["bankname"]; ?>");
					        $('#cash').val("<?php echo $demo_data["cash"]; ?>");
					        
					        $('#gtotal').val("<?php echo $demo_data["gtotal"]; ?>");
					        $('#referencenumber').val("<?php echo $demo_data["referencenumber"]; ?>");
					        $('#gst').val("<?php echo $demo_data["gst"]; ?>");
                        });
					</script>
					</body>
				</html>
<?php
    $con->close();
  }
  else
  {
      header('location:login.php');
  }
?>
